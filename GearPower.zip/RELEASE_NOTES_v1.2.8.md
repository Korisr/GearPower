# GearPower v1.2.8

开机启动静默化修复。

## 修复

- **自启不再唤出程序窗口**
  - 原因：v1.2.7 用 `app.Run(window)` 启动，WPF 会强制 `Show()` 主窗口；`Opacity=0` 只是把窗口画成全透明，窗口本身仍被创建、仍参与 DWM 合成，登录瞬间就会闪出一块黑屏
  - 修复：自启时改用无参 `app.Run()`，只跑消息循环，主窗口**从不调用 `Show()`**，进程里连窗口句柄都不存在
  - 实测后台启动后 `IsVisible=False`、`HWND=0`，登录后只会看到托盘电池图标

- **初始化时机改为首次显示**
  - 托盘图标、任务栏电量条、首次扫描与刷新定时器从 `Window_Loaded` 抽到独立的 `InitializeRuntime()`，自启路径由 dispatcher 直接调用
  - 加了 `runtimeInitialized` 守卫，之后从托盘打开窗口不会重复初始化

- **关闭行为对齐**
  - 自启进程无窗口时使用 `ShutdownMode.OnExplicitShutdown`，否则消息循环会因为没有主窗口立刻结束
  - 从托盘打开窗口后自动切回 `OnMainWindowClose`，之后关闭窗口的行为与普通启动完全一致

- **兜底**
  - 自启时若托盘图标创建失败，回退为显示窗口，避免进程既无窗口也无托盘、无法退出

## 变更

- `StartHidden` 语义收窄为「真的不建窗口」，不再是「建了再藏起来」

## 验证

- 自检：87 项通过
- 后台启动实测：`PROBE visible=False hwnd=0 tray=True shutdown=OnExplicitShutdown`，首次扫描正常完成（3 台设备）

## 下载

- `GearPower.exe`

SHA256：

```text
e722816363c4c31f57d38e79cfea2fa8b8085f0a866ac6e025f59f342ec0069e
```

文件大小：`376,320` 字节

## 注意

- Windows 10/11 64 位，需要 .NET Framework 4.8
- exe 未签名，SmartScreen 可能提示未知发布者
- 已开启自启的用户无需任何操作，下次登录自动生效
